var app = angular.module('GridApp', ["ngRoute", 'angularUtils.directives.dirPagination']);
var site_prefix = 'http://localhost/angular/task';


// app.config(['$routeProvider', function ($routeProvider) {
//     //$locationProvider.hashPrefix('');
//     $routeProvider
//     .when(site_prefix +'/details/:id', {
//         controller: "GridController",
//         templateUrl : "views/details.html"
  
//     }).when('/', {
//             templateUrl: 'index.html'
//         });
        
//     }]);

// app.config(['$routeProvider', function($routeProvider) {
//     $routeProvider
//       .when('/home', {
//         template: "index.html"
//       })
//       .when('/details/:id/', {
//         templateUrl: "/views/details.html",
//         controller: 'GridController'
//       })
//       .otherwise({
//         redirectTo: '/home'
//       })
//   }]);

app.config(['$routeProvider', 
  function($routeProvider, $routeParams){
    $routeProvider
      .when('/home', {
        template: 'index.html'
      })
      .when('/details/:id', {
        template: '../views/details.html',
        controller: 'GridController'
      })
      .otherwise({
        redirectTo: '/'
      })
  }
]);